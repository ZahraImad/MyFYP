--
-- Database: `emr2`
--

-- --------------------------------------------------------

--
-- Table structure for table `allergies`
--

CREATE TABLE `allergies` (
  `id` int(10) UNSIGNED NOT NULL,
  `allergy_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `allergy_note` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(10) UNSIGNED NOT NULL,
  `checkup_reason` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeslot_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `checkup_reason`, `date`, `time`, `status`, `timeslot_id`, `employee_id`, `patient_id`, `created_at`, `updated_at`) VALUES
(2, 'fever', '2016-08-21', '17:17:00', '0', 146, 3, 14, '2016-08-20 14:18:32', '2016-08-20 14:18:32'),
(3, 'skin infection', '2016-08-27', '13:15:00', '0', 314, 14, 10, '2016-08-20 16:15:21', '2016-08-20 16:15:21'),
(4, '', '2016-08-14', '22:30:00', '0', 352, 19, 33, '2016-08-20 16:43:05', '2016-08-20 16:43:05'),
(5, 'coughing', '2016-08-03', '01:36:00', '0', 230, 13, 34, '2016-08-20 18:13:48', '2016-08-20 18:13:48'),
(6, '', '2016-08-14', '22:00:00', '0', 350, 19, 1, '2016-08-23 19:02:52', '2016-08-23 19:02:52');

-- --------------------------------------------------------

--
-- Table structure for table `balancesheets`
--

CREATE TABLE `balancesheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `total_amount` double NOT NULL,
  `payable_amount` double NOT NULL,
  `receivable_amount` double NOT NULL,
  `vendor_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `balancesheet_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beds`
--

CREATE TABLE `beds` (
  `id` int(10) UNSIGNED NOT NULL,
  `bed_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ward_id` int(11) NOT NULL,
  `ward_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `beds`
--

INSERT INTO `beds` (`id`, `bed_no`, `ward_id`, `ward_type`, `created_at`, `updated_at`, `status`, `patient_id`) VALUES
(7, '4324', 5, '', '2015-08-03 11:00:41', '2015-08-03 11:00:41', 'Act', '3'),
(8, '00000000', 6, '', '2015-08-03 11:01:14', '2015-08-03 11:01:14', 'IPD', '4'),
(9, '00000000', 7, 'female', '2015-08-03 11:05:13', '2015-08-03 11:05:13', 'Act', '5'),
(10, '11', 5, 'female', '2016-08-20 18:45:33', '2016-08-20 18:45:33', 'act', '6'),
(11, '22', 6, 'male', '2016-08-20 18:45:50', '2016-08-20 18:45:50', 'act', '7'),
(16, '3', 5, 'male', '2016-08-23 19:39:18', '2016-08-23 19:39:18', 'act', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_charges` double NOT NULL,
  `bed_charges` double NOT NULL,
  `operation_charges` double NOT NULL,
  `meal_charges` double NOT NULL,
  `medicine_charges` double NOT NULL,
  `total_charges` double NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bill_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `room_charges`, `bed_charges`, `operation_charges`, `meal_charges`, `medicine_charges`, `total_charges`, `note`, `patient_id`, `bill_id`, `created_at`, `updated_at`) VALUES
(1, 100, 200, 200, 200, 100, 1000, 'N/A', '14', 'B01', '2016-08-22 16:07:23', '2016-08-22 16:07:23');

-- --------------------------------------------------------

--
-- Table structure for table `checkupfees`
--

CREATE TABLE `checkupfees` (
  `id` int(10) UNSIGNED NOT NULL,
  `checkup_fee` double NOT NULL,
  `fee_note` text COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `checkupfees`
--

INSERT INTO `checkupfees` (`id`, `checkup_fee`, `fee_note`, `patient_id`, `appointment_id`, `created_at`, `updated_at`) VALUES
(1, 500, '', 14, 2, '2016-08-20 16:25:37', '2016-08-20 16:25:37'),
(2, 1000, '', 33, 4, '2016-08-20 18:07:08', '2016-08-20 18:07:08');

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--

CREATE TABLE `clinics` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`id`, `name`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Zahra ', 'lahore Cantt', '2016-08-01 14:35:20', '2016-08-01 14:35:20'),
(2, 'CMH lahore ', 'lahore Cantt', '2016-08-20 12:42:23', '2016-08-20 12:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `consumptions`
--

CREATE TABLE `consumptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `patient_id` int(11) NOT NULL,
  `meal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `medicine` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `others` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Bed` int(20) NOT NULL,
  `room` int(20) NOT NULL,
  `operation` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `consumptions`
--

INSERT INTO `consumptions` (`id`, `patient_id`, `meal`, `medicine`, `others`, `created_at`, `updated_at`, `Bed`, `room`, `operation`) VALUES
(2, 0, '120', '150', '15200', '2015-08-03 11:22:29', '2015-08-03 11:22:29', 0, 0, 0),
(3, 27, '100', '100', '', '2016-08-20 18:52:37', '2016-08-20 18:53:16', 100, 100, 100);

-- --------------------------------------------------------

--
-- Table structure for table `diagonosticprocedures`
--

CREATE TABLE `diagonosticprocedures` (
  `id` int(10) UNSIGNED NOT NULL,
  `procedure_note` text COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `diagonosticprocedures`
--

INSERT INTO `diagonosticprocedures` (`id`, `procedure_note`, `patient_id`, `appointment_id`, `created_at`, `updated_at`) VALUES
(1, 'kdfsfksdfklsd', 4, 1, '2016-08-11 12:35:29', '2016-08-11 12:35:29'),
(2, 'need operation', 14, 2, '2016-08-20 18:09:03', '2016-08-20 18:09:03'),
(3, 'need to help me out in project :(', 33, 4, '2016-08-20 18:09:20', '2016-08-20 18:09:20');

-- --------------------------------------------------------

--
-- Table structure for table `dispatchlists`
--

CREATE TABLE `dispatchlists` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `req_amount` double NOT NULL,
  `total_amount` double NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dispatch_list_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dispatchlists`
--

INSERT INTO `dispatchlists` (`id`, `name`, `req_amount`, `total_amount`, `note`, `dispatch_list_id`, `created_at`, `updated_at`, `Status`) VALUES
(1, 'Dicloran', 10000, 10000000, 'ASAP needed', 'D0', '2016-08-22 16:22:37', '2016-08-22 16:22:37', 'active'),
(2, 'panadol', 100000, 1000000, 'need it ', 'D0', '2016-08-22 16:27:54', '2016-08-22 16:27:54', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `drugusages`
--

CREATE TABLE `drugusages` (
  `id` int(10) UNSIGNED NOT NULL,
  `drug_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `usage_note` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dutydays`
--

CREATE TABLE `dutydays` (
  `id` int(10) UNSIGNED NOT NULL,
  `day` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start` time DEFAULT NULL,
  `end` time DEFAULT NULL,
  `employee_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dutydays`
--

INSERT INTO `dutydays` (`id`, `day`, `start`, `end`, `employee_id`, `created_at`, `updated_at`) VALUES
(1, 'Sunday', '17:02:00', '18:00:00', 3, '2015-08-03 10:37:47', '2016-08-20 14:01:33'),
(2, 'Monday', '13:04:00', '14:00:00', 3, '2015-08-03 10:37:47', '2016-08-20 14:07:29'),
(3, 'Tuesday', '01:00:00', '20:00:00', 3, '2015-08-03 10:37:47', '2016-08-20 14:07:30'),
(4, 'Wednesday', '01:36:00', '12:59:00', 3, '2015-08-03 10:37:47', '2016-08-20 14:07:38'),
(5, NULL, NULL, NULL, 3, '2015-08-03 10:37:47', '2015-08-03 10:37:47'),
(6, NULL, NULL, NULL, 3, '2015-08-03 10:37:47', '2015-08-03 10:37:47'),
(7, NULL, NULL, NULL, 3, '2015-08-03 10:37:47', '2015-08-03 10:37:47'),
(8, 'Sunday', '04:00:00', '05:55:00', 10, '2016-08-11 11:18:57', '2016-08-20 13:55:51'),
(9, NULL, NULL, NULL, 10, '2016-08-11 11:18:57', '2016-08-11 11:18:57'),
(10, NULL, NULL, NULL, 10, '2016-08-11 11:18:57', '2016-08-11 11:18:57'),
(11, NULL, NULL, NULL, 10, '2016-08-11 11:18:57', '2016-08-11 11:18:57'),
(12, NULL, NULL, NULL, 10, '2016-08-11 11:18:57', '2016-08-11 11:18:57'),
(13, NULL, NULL, NULL, 10, '2016-08-11 11:18:57', '2016-08-11 11:18:57'),
(14, NULL, NULL, NULL, 10, '2016-08-11 11:18:58', '2016-08-11 11:18:58'),
(15, 'Sunday', '12:00:00', '00:00:00', 13, '2016-08-20 13:24:05', '2016-08-20 13:24:05'),
(16, 'Monday', '12:00:00', '00:00:00', 13, '2016-08-20 13:24:05', '2016-08-20 13:24:05'),
(17, 'Tuesday', '12:00:00', '00:00:00', 13, '2016-08-20 13:24:05', '2016-08-20 13:24:05'),
(18, NULL, NULL, NULL, 13, '2016-08-20 13:24:06', '2016-08-20 14:12:02'),
(19, NULL, NULL, NULL, 13, '2016-08-20 13:24:06', '2016-08-20 14:12:02'),
(20, NULL, NULL, NULL, 13, '2016-08-20 13:24:06', '2016-08-20 14:12:02'),
(21, NULL, NULL, NULL, 13, '2016-08-20 13:24:06', '2016-08-20 14:12:02'),
(22, 'Sunday', '13:00:00', '22:00:00', 14, '2016-08-20 16:14:27', '2016-08-20 16:14:27'),
(23, NULL, NULL, NULL, 14, '2016-08-20 16:14:33', '2016-08-20 16:14:33'),
(24, NULL, NULL, NULL, 14, '2016-08-20 16:14:33', '2016-08-20 16:14:33'),
(25, NULL, NULL, NULL, 14, '2016-08-20 16:14:33', '2016-08-20 16:14:33'),
(26, NULL, NULL, NULL, 14, '2016-08-20 16:14:33', '2016-08-20 16:14:33'),
(27, NULL, NULL, NULL, 14, '2016-08-20 16:14:33', '2016-08-20 16:14:33'),
(28, 'Saturday', '13:00:00', '22:00:00', 14, '2016-08-20 16:14:33', '2016-08-20 16:14:33'),
(29, 'Sunday', '22:00:00', '23:00:00', 19, '2016-08-20 16:42:28', '2016-08-20 16:42:28'),
(30, NULL, NULL, NULL, 19, '2016-08-20 16:42:28', '2016-08-20 16:42:28'),
(31, NULL, NULL, NULL, 19, '2016-08-20 16:42:28', '2016-08-20 16:42:28'),
(32, NULL, NULL, NULL, 19, '2016-08-20 16:42:28', '2016-08-20 16:42:28'),
(33, NULL, NULL, NULL, 19, '2016-08-20 16:42:28', '2016-08-20 16:42:28'),
(34, NULL, NULL, NULL, 19, '2016-08-20 16:42:28', '2016-08-20 16:42:28'),
(35, NULL, NULL, NULL, 19, '2016-08-20 16:42:29', '2016-08-20 16:42:29');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cnic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `branch` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clinic_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `password`, `email`, `gender`, `age`, `city`, `country`, `address`, `phone`, `cnic`, `branch`, `note`, `status`, `role`, `created_at`, `updated_at`, `remember_token`, `clinic_id`) VALUES
(1, 'Fahad Ali', '$2y$10$bS66f7PXvrMVKQLXK.aYV.dj9m3q7QWbR78YneVusZmG0.hXUbpea', 'super@gmail.com', 'Male', 23, 'Lahore', 'Pakistan', '10 Down Street', '03344050495', '1234679', 'DHA', 'MBBS Qualified', 'Active', 'Super User', '2015-05-20 14:49:37', '2015-05-20 14:49:37', NULL, NULL),
(2, 'Shah', '$2y$10$U5QZZ9R4lnnuLRwhxf5A1uDY0DmsjoervtY8W7JVEhFwykl0AZea2', 'admin@gmail.com', 'Male', 23, 'Lahore', 'Pakistan', '10 Down Street', '03344050495', '1234679', 'DHA', 'MBBS Qualified', 'Active', 'Administrator', '2015-05-20 14:49:37', '2015-05-20 14:49:37', NULL, 1),
(3, 'Ali', '$2y$10$zklTr5WF7Ao15LIeQ60jX.7mT1D/M.dAjQCJ4kyRLs6MSSSlgqzEq', 'doctor@gmail.com', 'Male', 23, 'Lahore', 'Pakistan', '10 Down Street', '03344050495', '1234679', 'DHA', 'MBBS Qualified', 'Active', 'Doctor', '2015-05-20 14:49:37', '2015-05-20 14:49:37', NULL, 1),
(4, 'Umer', '$2y$10$Qt9tqReVQHBNTDfs65DTC.y2hyFrLFKo3NnTY/saPSVI6ogyQh75u', 'accountant@gmail.com', 'Male', 23, 'Lahore', 'Pakistan', '10 Down Street', '03344050495', '1234679', 'DHA', 'MBBS Qualified', 'Active', 'Accountant', '2015-05-20 14:49:37', '2015-05-20 14:49:37', NULL, 1),
(5, 'Talal', '$2y$10$WIehwE/bL78XSqyKvWcSduwUz.bKJqbKnRjdBqewUwGgtmG6TlAQW', 'receptionist@gmail.com', 'Male', 23, 'Lahore', 'Pakistan', '10 Down Street', '03344050495', '1234679', 'DHA', 'MBBS Qualified', 'Active', 'Receptionist', '2015-05-20 14:49:37', '2015-05-20 14:49:37', NULL, 1),
(6, 'Aqeel', '$2y$10$mKEsCdmA4HxiZd2bW3Wasefd02437zaodean6kNQ18TnHOfIkQRKS', 'lab@gmail.com', 'Male', 23, 'Lahore', 'Pakistan', '10 Down Street', '03344050495', '1234679', 'DHA', 'MBBS Qualified', 'Active', 'Lab Manager', '2015-05-20 14:49:37', '2015-05-20 14:49:37', NULL, 1),
(7, 'Mehwish', '$2y$10$rr64/FZ5Fdy2ihLCggcuS.KfdLplce5779dHLPGTqD5vPXvSk186i', 'nurse@gmail.com', 'Female', 20, 'Lahore', 'Pakistan', 'gulshan ravi', '(0092) 333-4569877', '35252-4587569-3', 'Gulberg', 'N/A', 'Active', 'Nurse', '2015-05-21 13:07:14', '2015-05-21 13:23:38', NULL, NULL),
(8, 'Hamza', '$2y$10$a4iVx2KhLPtKtbSX/c0obeqGTuvkpngwjji8ZGhWRbvgIw66WGfdW', 'pharmacy@gmail.com', 'Male', 20, 'lahore', 'Pakistan', 'gulshan ravi', '(0092) 333-4569877', '35252-4587569-3', 'Gulberg', 'N/A', 'Active', 'Pharmacy Manager', '2015-05-21 13:10:54', '2015-05-21 13:22:28', NULL, NULL),
(9, 'admin', '$2y$10$QSzWKTBTRZV4nee7PrFgjOGf2DRbs28ojE2TdLZ6CI4WZTu8IpcTy', 'zahraimadgill@gmail.com', 'Female', 22, 'lahore', 'Pakistan', 'hahfddkfu', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Administrator', '2016-08-01 14:35:20', '2016-08-01 14:35:20', NULL, 1),
(10, 'Dr Zahra ', '$2y$10$UFma04mQ7vKBkVLJaoDZXOTo9akUBa/3ZA3eyJdvPUAHbLjraaZWu', 'zahra@gmail.com', 'Female', 22, 'lahore', 'Pakistan', 'suddukwe', '(0092) 333-4051518', '35201-7467652-2', 'DHA', 'best doctor ', 'Active', 'Doctor', '2016-08-01 15:06:07', '2016-08-01 15:06:08', NULL, NULL),
(11, 'receptionist', '$2y$10$3Dd26KIo/xfu1tMiqle.A.IOkm21D1XR4523/FqHMSqzLDMAjQsDG', 'receptionist1@gmail.com', 'Female', 33, 'lahore', 'Pakistan', 'dkgdfpseerwk', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Receptionist', '2016-08-01 15:17:34', '2016-08-01 15:17:34', NULL, NULL),
(12, 'Haider', '$2y$10$q8CqjvhSpgHwPQuwLej2nONmYspAfqI3fdlO45H2AnLp1YhicmXaG', 'adminhaider@gmail.com', 'Male', 9, 'lahore', 'Pakistan', 'drtdf', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Administrator', '2016-08-20 12:42:24', '2016-08-20 12:42:24', NULL, 2),
(13, 'Dr haider', '$2y$10$IbQpU7k4jBn8kOhwIdGl7uGL2rgHYmv.HyAWO5oKLclSYZ77l.m8a', 'drhaider@gmail.com', 'Male', 22, 'lahore', 'Pakistan', 'frt', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 13:22:00', '2016-08-20 13:22:00', NULL, NULL),
(14, 'dr eeraj ', '$2y$10$uTlNCqSm6iJayuCxYL1zWOflU/0g3tqD48/TDUICm6RE8VHSONhuO', 'dreeraj@gmail.com', 'Female', 16, 'Lahore ', 'Pakistan', 'zifdlskerekfsdogjrg', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:10:30', '2016-08-20 16:10:31', NULL, NULL),
(15, 'dr eeraj ', '$2y$10$KSwFfI/JABxaDbpqN8Ey.eaGh9QNRJ.IMwVd4JVUILEJOv/3Zti/G', 'dreeraj@hospital.com', 'Female', 16, 'Lahore ', 'Pakistan', 'zifdlskerekfsdogjrg', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:11:30', '2016-08-20 16:11:31', NULL, NULL),
(16, 'dr eeraj ', '$2y$10$IiQTpphPk/gANsgEyocr/.xJ6XPrMt8zgEBzhs37SGujUWTOmkHJW', 'dreeraj1@hospital.com', 'Female', 16, 'Lahore ', 'Pakistan', 'zifdlskerekfsdogjrg', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:13:18', '2016-08-20 16:13:19', NULL, NULL),
(17, 'Dr John', '$2y$10$iCQYsSqXm4bSIIzO1k1SBeBrCqcTtp1q4LdoaiZs7QRrhsUn6lZqa', 'drjohn@gmail.com', 'Male', 55, 'Lahore ', 'Pakistan', 'szjdedjvdfgdog', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:17:36', '2016-08-20 16:17:37', NULL, NULL),
(18, 'dr saba', '$2y$10$w109ca/Fc.1hvQEB2LqN8eFtmflCe2DPy/Dyj/yLBcNfzTePpSiKy', 'drsaba@gmail.com', 'Male', 55, 'Lahore ', 'Pakistan', 'szjdedjvdfgdog', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:18:53', '2016-08-20 16:18:54', NULL, NULL),
(19, 'dr samina', '$2y$10$BMowoWC6Pt.RMIwptt0Sc.I6k9a6XkVr/9oHwijxg9lFvMChB.j..', 'samina@gmail.com', 'Female', 45, 'Lahore ', 'Pakistan', 'dfndfdfks', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:20:45', '2016-08-20 16:20:46', NULL, NULL),
(20, 'dr samina imad', '$2y$10$BY1bd1O08fwYFOarPX/yp.CQyWQ63OtQFCWW7JYT91WWUl7zBrMTa', 'samina@abc.com', 'Female', 45, 'Lahore ', 'Pakistan', 'dfndfdfks', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:21:57', '2016-08-20 16:21:58', NULL, NULL),
(21, 'dr sabih ', '$2y$10$p6onFsqBJf5ZcthKqH3qVePpruFaap8SqoT9Hxg6Uvjf2AV2vxQEG', 'sabih@gmail.com', 'Male', 22, 'lahore', 'Pakistan', 'sdufsififf', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Doctor', '2016-08-20 16:35:47', '2016-08-20 16:35:48', NULL, NULL),
(22, 'blah blah', '$2y$10$DNvgontcaE34uB39WJbdm.ymCyqQj2Ql9R/tSJqxl30f1A7IXpOX.', 'blah@gmail.com', 'Male', 10, 'Lahore ', 'Pakistan', 'dufhdfu', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Lab Manager', '2016-08-20 16:37:15', '2016-08-20 16:37:16', NULL, NULL),
(23, 'blah blah', '$2y$10$4OTb.7oWLLFrjf6T8VkidOsPBSCV8gov.QsEAB8OAbJ.k90sfU8hi', 'blah9988@gmail.com', 'Male', 10, 'Lahore ', 'Pakistan', 'dufhdfu', 'N/A', 'N/A', 'N/A', 'N/A', 'Active', 'Lab Manager', '2016-08-20 16:41:02', '2016-08-20 16:41:02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `familyhistories`
--

CREATE TABLE `familyhistories` (
  `id` int(10) UNSIGNED NOT NULL,
  `f_member_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `patient_relation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `diesease_note` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `familyhistories`
--

INSERT INTO `familyhistories` (`id`, `f_member_name`, `patient_relation`, `gender`, `age`, `diesease_note`, `created_at`, `updated_at`, `patient_id`) VALUES
(1, 'Gill', 'Tahir ', 'Male', 10, 'Skin infection ', '2016-08-20 16:24:13', '2016-08-20 16:24:13', '27'),
(2, 'Gill', 'Tahir ', 'Male', 10, 'Skin infection ', '2016-08-20 16:24:26', '2016-08-20 16:24:26', '27');

-- --------------------------------------------------------

--
-- Table structure for table `labtests`
--

CREATE TABLE `labtests` (
  `id` int(10) UNSIGNED NOT NULL,
  `test_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `test_description` text COLLATE utf8_unicode_ci NOT NULL,
  `total_fee` double NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `test_results` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `labtests`
--

INSERT INTO `labtests` (`id`, `test_name`, `test_description`, `total_fee`, `patient_id`, `appointment_id`, `test_results`, `created_at`, `updated_at`) VALUES
(1, 'fever', '103 temp', 20, 14, 2, '', '2016-08-20 16:28:36', '2016-08-20 16:29:09');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `name`, `description`, `quantity`, `created_at`, `updated_at`) VALUES
(1, 'panadol', 'for fever', 99, '2016-08-20 13:25:24', '2016-08-20 16:27:38'),
(2, 'bruffen', 'cough', 99, '2016-08-20 13:26:13', '2016-08-20 18:08:42'),
(3, 'Dicloran', 'For Muscle Pain', 100, '2016-08-22 15:57:47', '2016-08-22 15:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_01_28_184838_create_employees_table', 1),
('2015_02_03_060752_create_patients_table', 1),
('2015_02_05_194923_add_remember_token_to_employees_table', 1),
('2015_02_06_062003_create_surgicalhistories_table', 1),
('2015_02_06_103433_create_familyhistories_table', 1),
('2015_02_10_120710_create_previousdiseases_table', 1),
('2015_02_11_060123_create_allergies_table', 1),
('2015_02_11_070250_create_drugusages_table', 1),
('2015_02_11_074218_create_diagonosticprocedures_table', 1),
('2015_02_11_095950_create_vitalsigns_table', 1),
('2015_02_12_084106_add_patient_id_to_allergies_table', 1),
('2015_02_12_084722_add_patient_id_to_drugusages_table', 1),
('2015_02_12_085330_add_patient_id_to_familyhistories_table', 1),
('2015_02_12_085656_add_patient_id_to_previousdiseases_table', 1),
('2015_02_12_090044_add_patient_id_to_surgicalhistories_table', 1),
('2015_02_14_110516_create_dutydays_table', 1),
('2015_02_14_111359_create_timeslots_table', 1),
('2015_02_17_060819_create_labtests_table', 1),
('2015_02_17_080659_create_appointments_table', 1),
('2015_02_18_064352_create_prescriptions_table', 1),
('2015_02_19_192700_create_password_reminders_table', 1),
('2015_02_21_053340_create_checkupfees_table', 1),
('2015_02_21_053926_create_testfees_table', 1),
('2015_04_04_133230_add_employee_id_to_timeslots_table', 1),
('2015_05_07_230614_drop_fields_from_vital_signs_table', 1),
('2015_05_09_120745_create_medicines_table', 1),
('2015_05_14_011058_add_procedure_to_prescriptions_table', 1),
('2015_05_17_123801_create_clinics_table', 1),
('2015_05_17_124556_add_clinic_id_to_employees_table', 1),
('2015_05_28_125653_create_vendors_table', 1),
('2015_05_29_211006_create_beds_table', 1),
('2015_06_02_134709_create_balancesheets_table', 1),
('2015_06_02_140449_add_note_to_balancesheets_table', 1),
('2015_06_04_134058_create_wards_table', 1),
('2015_06_06_112447_create_bills_table', 1),
('2015_06_12_095649_create_rooms_table', 1),
('2015_06_12_112957_create_dispatchlists_table', 1),
('2015_06_12_194058_create_Consumptions_table', 1),
('2015_06_12_194305_create_update_HS_table', 1),
('2015_08_06_140236_create_opt_table', 2),
('2015_08_06_142246_create_beds_table', 3),
('2015_08_13_132114_create_Consumptions_table', 4),
('2015_08_17_112240_create_dispatchlists_table', 5),
('2015_08_17_200925_create_rooms_table', 5),
('2015_09_04_181559_create_patients_table', 5),
('2016_08_23_235645_add_patient_name_to_beds_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `opt`
--

CREATE TABLE `opt` (
  `id` int(10) UNSIGNED NOT NULL,
  `operation_reason` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeslot_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `opt`
--

INSERT INTO `opt` (`id`, `operation_reason`, `date`, `time`, `status`, `timeslot_id`, `employee_id`, `patient_id`, `created_at`, `updated_at`) VALUES
(1, 'ferd', '2016-08-22', '13:19:00', '0', 150, 3, 25, '2016-08-20 16:02:10', '2016-08-20 16:02:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_reminders`
--

CREATE TABLE `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cnic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ward` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bed` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ward_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `dob`, `gender`, `age`, `email`, `city`, `country`, `address`, `phone`, `cnic`, `ward`, `bed`, `room`, `note`, `patient_id`, `ward_id`, `created_at`, `updated_at`, `status`) VALUES
(1, 'trtr', '2016-08-18', 'Male', 0, 'N/A', 'lahore', 'Pakistan', 'dgdfgdfgd', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-11 12:01:26', '2016-08-11 12:01:26', ''),
(3, 'ali', '2015-08-04', 'Male', 0, 'zeeshe707@gmail.com', 'lahore', 'Pakistan', 'lahore street', '(0000) 000-0000000', '00000-0000000-0', '', '8', '3', 'chal ja kaka', 'P03', 6, '2015-08-03 11:07:26', '2015-08-03 11:07:27', ''),
(4, 'faria', '1994-01-31', 'Female', 21, 'nurse@gmail.com', 'lahore', 'Pakistan', 'lahore street', '(0002) 222-2222222', '02222-2222222-2', '', '9', '4', 'faria is added', 'P04', 7, '2015-08-03 11:12:47', '2015-08-03 11:12:48', ''),
(5, 'abc', '2016-08-12', 'Male', 0, 'doctor@gmail.com', 'lahore', 'Pakistan', 'sadsfdsdsfs', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-11 11:46:16', '2016-08-11 11:46:16', ''),
(6, 'bcbc', '2016-08-12', 'Female', 0, 'fsfsdfsd@gmail.com', 'lahore', 'Pakistan', 'sdskldksad', '(3424) 324-2342342', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-11 11:47:44', '2016-08-11 11:47:44', ''),
(7, 'dfdsf', '2016-08-10', 'Male', 0, 'fdsfsdfs@gmail.com', 'lahore', 'Pakistan', 'kjdslkfdsjlf', 'N/A', 'N/A', '', '', '', 'N/A', '1', 0, '2016-08-11 11:49:36', '2016-08-11 11:49:36', ''),
(8, 'ewrrew', '2016-08-17', 'Female', 0, 'ewewrwe@gmail.com', 'lahore', 'Pakistan', 'kfjdskfjldskjfs', 'N/A', 'N/A', '', '', '', 'N/A', '1', 0, '2016-08-11 11:50:26', '2016-08-11 11:50:26', ''),
(9, 'fsdf', '2016-08-18', 'Male', 0, 'N/A', 'lahore', 'Pakistan', 'fdsfdsfsdfsd', 'N/A', 'N/A', '', '', '', 'N/A', '1', 0, '2016-08-11 11:58:05', '2016-08-11 11:58:05', ''),
(10, 'Tahir ', '2017-12-31', 'Male', -1, 'xzgxjs@fdj.com', 'Lahore', 'Pakistan', 'sdhseje', '(0092) 343-8429890', '23718-2372824-2', '', '', '', 'dskdjweile', 'P0', 0, '2016-08-18 06:18:43', '2016-08-18 06:18:43', ''),
(11, 'bvnn', '2015-11-30', 'Male', 1, 'gff@jkhjhg.com', 'Lahore', 'Yemen', 'hgvjh', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-18 06:21:07', '2016-08-18 06:21:07', ''),
(12, 'new', '2016-12-01', 'Male', 0, 'zag@gm.com', 'Lahore', 'Pakistan', 'sduhusefs', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 08:51:13', '2016-08-20 08:51:13', ''),
(13, 'zzz', '2016-12-31', 'Male', 0, 'djfn@fm.com', 'lahore', 'Pakistan', 'cdfs', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 09:08:22', '2016-08-20 09:08:22', ''),
(14, 'mohid', '2016-12-31', 'Male', 0, 'fdsfsdfs@gmail.com', 'lahore', 'Pakistan', 'zfsd', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 09:31:14', '2016-08-20 09:31:14', ''),
(22, 'sds', '2013-12-31', 'Male', 3, 'N/A', 'lahore', 'Pakistan', 'sadasd', 'N/A', 'N/A', '', '', '', 'gfg', 'P022', 0, '2016-08-20 09:33:17', '2016-08-20 09:33:17', ''),
(23, 'new new ', '2011-12-29', 'Male', 5, 'gff@jkhjhg.com', 'lahore', 'Pakistan', 'hgherg', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 09:39:00', '2016-08-20 09:39:00', ''),
(24, 'tttt', '2013-12-29', 'Male', 3, 'N/A', 'lahore', 'Pakistan', 'idfhgfdg', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 09:39:44', '2016-08-20 09:39:44', ''),
(25, 'ghg', '2005-11-21', 'Male', 11, 'N/A', 'lahore', 'Pakistan', 'jkjk', 'N/A', 'N/A', '', '', '', 'hjjhjhj', 'P0', 0, '2016-08-20 09:44:45', '2016-08-20 09:44:45', ''),
(26, 'abcabc', '2008-05-25', 'Male', 8, 'N/A', 'lahore', 'Pakistan', 'mnmasndas', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 09:47:34', '2016-08-20 09:47:34', 'IPD'),
(27, 'aaaaa', '2011-09-19', 'Male', 5, 'N/A', 'lahore', 'Pakistan', 'sadsadas', 'N/A', 'N/A', '', '', '', 'dasdasdas', 'P05', 0, '2016-08-20 10:02:52', '2016-08-20 10:02:52', 'IPD'),
(28, 'nan', '2007-08-26', 'Male', 9, 'N/A', 'lahore', 'Pakistan', 'jjjj', 'N/A', 'N/A', '', '', '', 'N/A', 'P09', 0, '2016-08-20 10:03:41', '2016-08-20 10:03:41', 'IPD'),
(29, 'sdsdsds11', '2009-11-22', 'Male', 7, 'N/A', 'Lahore ', 'Pakistan', 'setdxhfb', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 10:14:35', '2016-08-20 10:14:35', 'IPD'),
(30, 'zahraaaaa', '2007-12-27', 'Male', 9, 'N/A', 'lahore', 'Pakistan', 'DUSFSDIS', 'N/A', 'N/A', '', '', '', 'N/A', 'P09', 0, '2016-08-20 10:28:57', '2016-08-20 10:28:57', 'OPD'),
(31, 'tahir ali mota ', '2012-11-28', 'Male', 4, 'N/A', 'islamabad', 'Pakistan', 'jfesfkisd', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 11:21:42', '2016-08-20 11:21:42', 'IPD'),
(32, 'kashif', '2000-08-28', 'Male', 16, 'N/A', 'lahore', 'Pakistan', 'ghghgh', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 14:41:09', '2016-08-20 14:41:09', ''),
(33, 'sabih', '2018-10-30', 'Female', -2, 'asdfasf@gmsail.com', 'lahore', 'Pakistan', 'vvv', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 15:14:17', '2016-08-20 15:14:17', ''),
(34, 'zahra imad gill', '1994-05-03', 'Female', 22, 'zahraimadgill@gmail.com', 'lahore', 'Pakistan', 'hsudhska', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-20 16:44:20', '2016-08-20 16:44:20', ''),
(35, 'Syed Sabih Haider ', '1993-09-21', 'Male', 23, 'sabhiaown93@hotmail.com', 'Lahore', 'Pakistan', 'ckfjsdlfnz.', 'N/A', 'N/A', '', '', '', 'N/A', 'P0', 0, '2016-08-22 16:00:42', '2016-08-22 16:00:42', '');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `medicines` text COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `procedure` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `code`, `medicines`, `note`, `patient_id`, `appointment_id`, `created_at`, `updated_at`, `procedure`) VALUES
(1, '001', '1', 'diagnosed with fever ', 14, 2, '2016-08-20 16:27:38', '2016-08-20 16:27:38', 'Take 3 times a day for a week'),
(2, '0001', '2', 'dgdr', 33, 4, '2016-08-20 18:08:42', '2016-08-20 18:08:42', 'fgr');

-- --------------------------------------------------------

--
-- Table structure for table `previousdiseases`
--

CREATE TABLE `previousdiseases` (
  `id` int(10) UNSIGNED NOT NULL,
  `disease_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `disease_notes` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `room_location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `room_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_type`, `room_location`, `room_no`, `patient_id`, `created_at`, `updated_at`, `Status`) VALUES
(1, 'ttt', 'sadfa', '63', '3', '2015-08-03 10:06:01', '2015-08-03 10:06:01', 'Active'),
(2, 'ttt', 'sadfa', '99', '4', '2015-08-03 10:06:17', '2015-08-03 10:06:17', 'Active'),
(8, 'vip ', 'first floor', '2', '5', '2016-08-20 18:48:16', '2016-08-20 18:48:16', 'active'),
(9, 'r', 'g', '5', '6', '2016-08-24 20:16:05', '2016-08-24 20:16:05', 'active'),
(10, 't', 'g', '6', '7', '2016-08-24 20:18:46', '2016-08-24 20:18:46', 'active'),
(11, 't', 'y', '6', '1', '2016-08-24 20:22:39', '2016-08-24 20:22:39', 'active'),
(12, 'vip', 'first floor', '8', '25', '2016-08-24 20:49:07', '2016-08-24 20:49:07', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `surgicalhistories`
--

CREATE TABLE `surgicalhistories` (
  `id` int(10) UNSIGNED NOT NULL,
  `surgery_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `surgery_date` date NOT NULL,
  `surgery_notes` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `testfees`
--

CREATE TABLE `testfees` (
  `id` int(10) UNSIGNED NOT NULL,
  `test_fee` double NOT NULL,
  `fee_note` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timeslots`
--

CREATE TABLE `timeslots` (
  `id` int(10) UNSIGNED NOT NULL,
  `slot` time NOT NULL,
  `dutyday_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `timeslots`
--

INSERT INTO `timeslots` (`id`, `slot`, `dutyday_id`, `created_at`, `updated_at`, `employee_id`) VALUES
(133, '04:00:00', 8, '2016-08-20 13:55:51', '2016-08-20 13:55:51', 0),
(134, '04:15:00', 8, '2016-08-20 13:55:51', '2016-08-20 13:55:51', 0),
(135, '04:30:00', 8, '2016-08-20 13:55:51', '2016-08-20 13:55:51', 0),
(136, '04:45:00', 8, '2016-08-20 13:55:51', '2016-08-20 13:55:51', 0),
(137, '05:00:00', 8, '2016-08-20 13:55:51', '2016-08-20 13:55:51', 0),
(138, '05:15:00', 8, '2016-08-20 13:55:51', '2016-08-20 13:55:52', 0),
(139, '05:30:00', 8, '2016-08-20 13:55:52', '2016-08-20 13:55:52', 0),
(140, '05:45:00', 8, '2016-08-20 13:55:52', '2016-08-20 13:55:52', 0),
(145, '17:02:00', 1, '2016-08-20 14:07:29', '2016-08-20 14:07:29', 0),
(146, '17:17:00', 1, '2016-08-20 14:07:29', '2016-08-20 14:07:29', 0),
(147, '17:32:00', 1, '2016-08-20 14:07:29', '2016-08-20 14:07:29', 0),
(148, '17:47:00', 1, '2016-08-20 14:07:29', '2016-08-20 14:07:29', 0),
(149, '13:04:00', 2, '2016-08-20 14:07:29', '2016-08-20 14:07:29', 0),
(150, '13:19:00', 2, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(151, '13:34:00', 2, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(152, '13:49:00', 2, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(153, '01:00:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(154, '01:15:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(155, '01:30:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(156, '01:45:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(157, '02:00:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(158, '02:15:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(159, '02:30:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:30', 0),
(160, '02:45:00', 3, '2016-08-20 14:07:30', '2016-08-20 14:07:31', 0),
(161, '03:00:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(162, '03:15:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(163, '03:30:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(164, '03:45:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(165, '04:00:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(166, '04:15:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(167, '04:30:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(168, '04:45:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(169, '05:00:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(170, '05:15:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(171, '05:30:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:31', 0),
(172, '05:45:00', 3, '2016-08-20 14:07:31', '2016-08-20 14:07:32', 0),
(173, '06:00:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(174, '06:15:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(175, '06:30:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(176, '06:45:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(177, '07:00:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(178, '07:15:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(179, '07:30:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(180, '07:45:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(181, '08:00:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(182, '08:15:00', 3, '2016-08-20 14:07:32', '2016-08-20 14:07:32', 0),
(183, '08:30:00', 3, '2016-08-20 14:07:33', '2016-08-20 14:07:33', 0),
(184, '08:45:00', 3, '2016-08-20 14:07:33', '2016-08-20 14:07:33', 0),
(185, '09:00:00', 3, '2016-08-20 14:07:33', '2016-08-20 14:07:33', 0),
(186, '09:15:00', 3, '2016-08-20 14:07:33', '2016-08-20 14:07:34', 0),
(187, '09:30:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(188, '09:45:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(189, '10:00:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(190, '10:15:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(191, '10:30:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(192, '10:45:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(193, '11:00:00', 3, '2016-08-20 14:07:34', '2016-08-20 14:07:34', 0),
(194, '11:15:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(195, '11:30:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(196, '11:45:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(197, '12:00:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(198, '12:15:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(199, '12:30:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(200, '12:45:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(201, '13:00:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(202, '13:15:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(203, '13:30:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(204, '13:45:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(205, '14:00:00', 3, '2016-08-20 14:07:35', '2016-08-20 14:07:35', 0),
(206, '14:15:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(207, '14:30:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(208, '14:45:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(209, '15:00:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(210, '15:15:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(211, '15:30:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(212, '15:45:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(213, '16:00:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(214, '16:15:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(215, '16:30:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(216, '16:45:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(217, '17:00:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:36', 0),
(218, '17:15:00', 3, '2016-08-20 14:07:36', '2016-08-20 14:07:37', 0),
(219, '17:30:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(220, '17:45:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(221, '18:00:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(222, '18:15:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(223, '18:30:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(224, '18:45:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(225, '19:00:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(226, '19:15:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:37', 0),
(227, '19:30:00', 3, '2016-08-20 14:07:37', '2016-08-20 14:07:38', 0),
(228, '19:45:00', 3, '2016-08-20 14:07:38', '2016-08-20 14:07:38', 0),
(229, '20:00:00', 3, '2016-08-20 14:07:38', '2016-08-20 14:07:38', 0),
(230, '01:36:00', 4, '2016-08-20 14:07:38', '2016-08-20 14:07:38', 0),
(231, '01:51:00', 4, '2016-08-20 14:07:38', '2016-08-20 14:07:38', 0),
(232, '02:06:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(233, '02:21:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(234, '02:36:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(235, '02:51:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(236, '03:06:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(237, '03:21:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(238, '03:36:00', 4, '2016-08-20 14:07:39', '2016-08-20 14:07:39', 0),
(239, '03:51:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(240, '04:06:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(241, '04:21:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(242, '04:36:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(243, '04:51:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(244, '05:06:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(245, '05:21:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(246, '05:36:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(247, '05:51:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(248, '06:06:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(249, '06:21:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:40', 0),
(250, '06:36:00', 4, '2016-08-20 14:07:40', '2016-08-20 14:07:41', 0),
(251, '06:51:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(252, '07:06:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(253, '07:21:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(254, '07:36:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(255, '07:51:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(256, '08:06:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(257, '08:21:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(258, '08:36:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(259, '08:51:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(260, '09:06:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(261, '09:21:00', 4, '2016-08-20 14:07:41', '2016-08-20 14:07:41', 0),
(262, '09:36:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(263, '09:51:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(264, '10:06:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(265, '10:21:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(266, '10:36:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(267, '10:51:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(268, '11:06:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(269, '11:21:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(270, '11:36:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(271, '11:51:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(272, '12:06:00', 4, '2016-08-20 14:07:42', '2016-08-20 14:07:42', 0),
(273, '12:21:00', 4, '2016-08-20 14:07:43', '2016-08-20 14:07:43', 0),
(274, '12:36:00', 4, '2016-08-20 14:07:43', '2016-08-20 14:07:43', 0),
(275, '12:51:00', 4, '2016-08-20 14:07:43', '2016-08-20 14:07:43', 0),
(276, '13:00:00', 22, '2016-08-20 16:14:27', '2016-08-20 16:14:27', 14),
(277, '13:15:00', 22, '2016-08-20 16:14:27', '2016-08-20 16:14:27', 14),
(278, '13:30:00', 22, '2016-08-20 16:14:27', '2016-08-20 16:14:27', 14),
(279, '13:45:00', 22, '2016-08-20 16:14:27', '2016-08-20 16:14:27', 14),
(280, '14:00:00', 22, '2016-08-20 16:14:27', '2016-08-20 16:14:27', 14),
(281, '14:15:00', 22, '2016-08-20 16:14:27', '2016-08-20 16:14:28', 14),
(282, '14:30:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(283, '14:45:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(284, '15:00:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(285, '15:15:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(286, '15:30:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(287, '15:45:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(288, '16:00:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:28', 14),
(289, '16:15:00', 22, '2016-08-20 16:14:28', '2016-08-20 16:14:29', 14),
(290, '16:30:00', 22, '2016-08-20 16:14:29', '2016-08-20 16:14:29', 14),
(291, '16:45:00', 22, '2016-08-20 16:14:29', '2016-08-20 16:14:29', 14),
(292, '17:00:00', 22, '2016-08-20 16:14:29', '2016-08-20 16:14:29', 14),
(293, '17:15:00', 22, '2016-08-20 16:14:29', '2016-08-20 16:14:29', 14),
(294, '17:30:00', 22, '2016-08-20 16:14:30', '2016-08-20 16:14:30', 14),
(295, '17:45:00', 22, '2016-08-20 16:14:30', '2016-08-20 16:14:30', 14),
(296, '18:00:00', 22, '2016-08-20 16:14:30', '2016-08-20 16:14:30', 14),
(297, '18:15:00', 22, '2016-08-20 16:14:30', '2016-08-20 16:14:30', 14),
(298, '18:30:00', 22, '2016-08-20 16:14:30', '2016-08-20 16:14:31', 14),
(299, '18:45:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:31', 14),
(300, '19:00:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:31', 14),
(301, '19:15:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:31', 14),
(302, '19:30:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:31', 14),
(303, '19:45:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:31', 14),
(304, '20:00:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:31', 14),
(305, '20:15:00', 22, '2016-08-20 16:14:31', '2016-08-20 16:14:32', 14),
(306, '20:30:00', 22, '2016-08-20 16:14:32', '2016-08-20 16:14:32', 14),
(307, '20:45:00', 22, '2016-08-20 16:14:32', '2016-08-20 16:14:32', 14),
(308, '21:00:00', 22, '2016-08-20 16:14:32', '2016-08-20 16:14:32', 14),
(309, '21:15:00', 22, '2016-08-20 16:14:32', '2016-08-20 16:14:32', 14),
(310, '21:30:00', 22, '2016-08-20 16:14:32', '2016-08-20 16:14:32', 14),
(311, '21:45:00', 22, '2016-08-20 16:14:32', '2016-08-20 16:14:32', 14),
(312, '22:00:00', 22, '2016-08-20 16:14:33', '2016-08-20 16:14:33', 14),
(313, '13:00:00', 28, '2016-08-20 16:14:33', '2016-08-20 16:14:33', 14),
(314, '13:15:00', 28, '2016-08-20 16:14:33', '2016-08-20 16:14:33', 14),
(315, '13:30:00', 28, '2016-08-20 16:14:33', '2016-08-20 16:14:34', 14),
(316, '13:45:00', 28, '2016-08-20 16:14:34', '2016-08-20 16:14:34', 14),
(317, '14:00:00', 28, '2016-08-20 16:14:34', '2016-08-20 16:14:34', 14),
(318, '14:15:00', 28, '2016-08-20 16:14:34', '2016-08-20 16:14:34', 14),
(319, '14:30:00', 28, '2016-08-20 16:14:34', '2016-08-20 16:14:34', 14),
(320, '14:45:00', 28, '2016-08-20 16:14:34', '2016-08-20 16:14:35', 14),
(321, '15:00:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:35', 14),
(322, '15:15:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:35', 14),
(323, '15:30:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:35', 14),
(324, '15:45:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:35', 14),
(325, '16:00:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:35', 14),
(326, '16:15:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:35', 14),
(327, '16:30:00', 28, '2016-08-20 16:14:35', '2016-08-20 16:14:36', 14),
(328, '16:45:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(329, '17:00:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(330, '17:15:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(331, '17:30:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(332, '17:45:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(333, '18:00:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(334, '18:15:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:36', 14),
(335, '18:30:00', 28, '2016-08-20 16:14:36', '2016-08-20 16:14:37', 14),
(336, '18:45:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:37', 14),
(337, '19:00:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:37', 14),
(338, '19:15:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:37', 14),
(339, '19:30:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:37', 14),
(340, '19:45:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:37', 14),
(341, '20:00:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:37', 14),
(342, '20:15:00', 28, '2016-08-20 16:14:37', '2016-08-20 16:14:38', 14),
(343, '20:30:00', 28, '2016-08-20 16:14:38', '2016-08-20 16:14:38', 14),
(344, '20:45:00', 28, '2016-08-20 16:14:38', '2016-08-20 16:14:38', 14),
(345, '21:00:00', 28, '2016-08-20 16:14:38', '2016-08-20 16:14:38', 14),
(346, '21:15:00', 28, '2016-08-20 16:14:38', '2016-08-20 16:14:38', 14),
(347, '21:30:00', 28, '2016-08-20 16:14:38', '2016-08-20 16:14:38', 14),
(348, '21:45:00', 28, '2016-08-20 16:14:38', '2016-08-20 16:14:39', 14),
(349, '22:00:00', 28, '2016-08-20 16:14:39', '2016-08-20 16:14:39', 14),
(350, '22:00:00', 29, '2016-08-20 16:42:28', '2016-08-20 16:42:28', 19),
(351, '22:15:00', 29, '2016-08-20 16:42:28', '2016-08-20 16:42:28', 19),
(352, '22:30:00', 29, '2016-08-20 16:42:28', '2016-08-20 16:42:28', 19),
(353, '22:45:00', 29, '2016-08-20 16:42:28', '2016-08-20 16:42:28', 19),
(354, '23:00:00', 29, '2016-08-20 16:42:28', '2016-08-20 16:42:28', 19);

-- --------------------------------------------------------

--
-- Table structure for table `update_hs`
--

CREATE TABLE `update_hs` (
  `id` int(10) UNSIGNED NOT NULL,
  `patient_id` int(11) NOT NULL,
  `health_sheet` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `update_hs`
--

INSERT INTO `update_hs` (`id`, `patient_id`, `health_sheet`, `created_at`, `updated_at`) VALUES
(1, 27, 'cfhth', '2016-08-20 17:59:48', '2016-08-20 17:59:48');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vendor_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cnic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vendor_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `vendor_type`, `email`, `city`, `address`, `mobile`, `cnic`, `note`, `vendor_id`, `created_at`, `updated_at`) VALUES
(1, 'GSK', 'Medicine', 'asgay@fk.com', 'Lahore', 'dnsdnsl', 'N/A', 'N/A', 'N/A', 'V01', '2016-08-22 16:06:31', '2016-08-22 16:06:31');

-- --------------------------------------------------------

--
-- Table structure for table `vitalsigns`
--

CREATE TABLE `vitalsigns` (
  `id` int(10) UNSIGNED NOT NULL,
  `weight` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `height` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bp_systolic` int(11) NOT NULL,
  `bp_diastolic` int(11) NOT NULL,
  `blood_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pulse_rate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `respiration_rate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `temprature` int(11) NOT NULL,
  `temprature_unit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `patient_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `appointment_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vitalsigns`
--

INSERT INTO `vitalsigns` (`id`, `weight`, `height`, `bp_systolic`, `bp_diastolic`, `blood_group`, `pulse_rate`, `respiration_rate`, `temprature`, `temprature_unit`, `note`, `patient_id`, `appointment_id`, `created_at`, `updated_at`) VALUES
(1, '45', '23', 343, 343, 'A+', '33', '343', 233, 'F', '', '4', '1', '2016-08-11 12:36:26', '2016-08-11 12:36:26'),
(2, '59', '500', 23, 12, 'A+', '122', '22', 100, 'F', '', '34', '5', '2016-08-20 18:15:33', '2016-08-20 18:15:33');

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

CREATE TABLE `wards` (
  `id` int(10) UNSIGNED NOT NULL,
  `ward_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ward_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`id`, `ward_name`, `ward_type`, `created_at`, `updated_at`) VALUES
(5, 'surgery', 'male', '2015-08-03 10:55:55', '2015-08-03 10:55:55'),
(6, 'cardialogy', 'male', '2015-08-03 10:56:09', '2015-08-03 10:56:09'),
(7, 'neurology', 'female', '2015-08-03 10:56:22', '2015-08-03 10:56:22'),
(8, 'Surgery', 'female', '2016-08-20 18:38:23', '2016-08-20 18:38:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allergies`
--
ALTER TABLE `allergies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `balancesheets`
--
ALTER TABLE `balancesheets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beds`
--
ALTER TABLE `beds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkupfees`
--
ALTER TABLE `checkupfees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinics`
--
ALTER TABLE `clinics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consumptions`
--
ALTER TABLE `consumptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diagonosticprocedures`
--
ALTER TABLE `diagonosticprocedures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dispatchlists`
--
ALTER TABLE `dispatchlists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drugusages`
--
ALTER TABLE `drugusages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dutydays`
--
ALTER TABLE `dutydays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employees_clinic_id_foreign` (`clinic_id`);

--
-- Indexes for table `familyhistories`
--
ALTER TABLE `familyhistories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `labtests`
--
ALTER TABLE `labtests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `opt`
--
ALTER TABLE `opt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reminders`
--
ALTER TABLE `password_reminders`
  ADD KEY `password_reminders_email_index` (`email`),
  ADD KEY `password_reminders_token_index` (`token`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `previousdiseases`
--
ALTER TABLE `previousdiseases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surgicalhistories`
--
ALTER TABLE `surgicalhistories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testfees`
--
ALTER TABLE `testfees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timeslots`
--
ALTER TABLE `timeslots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `update_hs`
--
ALTER TABLE `update_hs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vitalsigns`
--
ALTER TABLE `vitalsigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wards`
--
ALTER TABLE `wards`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allergies`
--
ALTER TABLE `allergies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `balancesheets`
--
ALTER TABLE `balancesheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `beds`
--
ALTER TABLE `beds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `checkupfees`
--
ALTER TABLE `checkupfees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `clinics`
--
ALTER TABLE `clinics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `consumptions`
--
ALTER TABLE `consumptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `diagonosticprocedures`
--
ALTER TABLE `diagonosticprocedures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `dispatchlists`
--
ALTER TABLE `dispatchlists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `drugusages`
--
ALTER TABLE `drugusages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dutydays`
--
ALTER TABLE `dutydays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `familyhistories`
--
ALTER TABLE `familyhistories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `labtests`
--
ALTER TABLE `labtests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `opt`
--
ALTER TABLE `opt`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `previousdiseases`
--
ALTER TABLE `previousdiseases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `surgicalhistories`
--
ALTER TABLE `surgicalhistories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `testfees`
--
ALTER TABLE `testfees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `timeslots`
--
ALTER TABLE `timeslots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=355;
--
-- AUTO_INCREMENT for table `update_hs`
--
ALTER TABLE `update_hs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vitalsigns`
--
ALTER TABLE `vitalsigns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wards`
--
ALTER TABLE `wards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
